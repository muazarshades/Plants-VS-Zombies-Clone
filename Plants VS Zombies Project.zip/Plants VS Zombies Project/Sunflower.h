#pragma once
#include <iostream>
#include "Shooter.h"

#include <ctime>
#include <SFML/Graphics.hpp>

using namespace sf;
using namespace std;

class Sunflower : public Shooter {
public:
public:
	Sunflower() {
		plantTexture.loadFromFile("Images/Sunflower.png");
		plantSprite.setTexture(plantTexture);
		plantSprite.setScale(0.15f, 0.15f);
		plantSprite.setTextureRect(sf::IntRect(0, 0, 469, 532));
		bulletTexture.loadFromFile("Images/Sun.png");
		bulletSprite.setTexture(bulletTexture);
		bulletSprite.setScale(0.50, 0.50);
		bulletSprite.setTextureRect(sf::IntRect(0, 0, 80, 80));
		x = 0;
		y = 0;
		currency = 100;
		draw = false;
	}

	void MakingBullets(Clock& clk) {
		if (shooting == true && draw == true) {
			if (clk.getElapsedTime().asSeconds() < 10)
				return;
			clk.restart();
			for (int i = 0;i < maxBullets;++i) {
				if (bullet[i][2] == 0) {		
					bullet[i][0] = x + 32;
					bullet[i][1] = y;
					bullet[i][2] = 1;
					break;
				}
			}
			
		}
	}
	void CollectSunFlower(Sunflower &s,int& player_currency, int mouseX, int mouseY) {
		if (s.shooting == true) {
			for (int i = 0;i < s.maxBullets;++i) {
				if (s.bullet[i][2] == 1) {
					if (mouseX <= s.bullet[i][0] + 30 && s.bullet[i][0] + 5 <= mouseX) {
						if (mouseY <= s.bullet[i][1] + 30 && s.bullet[i][1] + 5 <= mouseY) {
							player_currency = player_currency + 50;
							s.bullet[i][2] = 3;

							break;
						}
					}
				}
			}
		}
			
	}
};