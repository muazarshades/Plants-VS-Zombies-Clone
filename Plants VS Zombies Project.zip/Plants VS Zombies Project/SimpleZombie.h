#pragma once
#include "Zombie.h"

class SimpleZombie : public Zombie {
private:
	int damage;

public:
	SimpleZombie()
		: Zombie(10.0f, 3), damage(10)
	{
		loadTexture(); // Load SimpleZombie texture
	}

	//for texture loading 
	void loadTexture() {
		texture.loadFromFile("Images/Zombie.png");
		sprite.setTexture(texture);
	}

	void spawn() {
		sf::Time elapsedTime = zombieClock.getElapsedTime();

		// spawn respawn
		if ((elapsedTime.asSeconds() > 5 || elapsedTime.asSeconds() > 200) && !alive) { // first time for initial spawn - second time for wave
			alive = true;
			zombieClock.restart();
		}
	}

	//virtual void plantZombieCollision() {

	//}

};