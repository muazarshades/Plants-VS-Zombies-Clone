#pragma once
#include "Zombie.h"

class DancingZombie : public Zombie {
public:
	DancingZombie()
		: Zombie(15.0f, 3)
	{
		loadTexture(); // Load SimpleZombie texture
	}

	//for texture loading 
	void loadTexture() {
		texture.loadFromFile("Images/DancingZombie.png");
		sprite.setTexture(texture);
		//sprite.setScale(.12f, .12f);
		sprite.setScale(0.180f, 0.110);//new
		sprite.setTextureRect(sf::IntRect(0, 0, 375, 500));//new
	}

	void spawn() {
		sf::Time elapsedTime = zombieClock.getElapsedTime();

		if ((elapsedTime.asSeconds() > 160 || elapsedTime.asSeconds() > 200) && !alive) { // first time for initial spawn - second time for wave
			alive = true;
			zombieClock.restart();
		}
	}
};