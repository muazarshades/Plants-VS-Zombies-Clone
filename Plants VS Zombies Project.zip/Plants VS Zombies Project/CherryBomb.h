#pragma once

#include <ctime>
#include <iostream>
#include <SFML/Graphics.hpp>


#include "Shooter.h"

using namespace sf;
using namespace std;

class CherryBomb : public Shooter {
public:
	bool explosion = false;
public:
	CherryBomb() {
		plantTexture.loadFromFile("Images/CherryBomb.png");
		plantSprite.setTexture(plantTexture);
		plantSprite.setScale(0.23f, 0.23f);
		plantSprite.setTextureRect(sf::IntRect(0, 0, 278, 271));
		x = 0;
		y = 0;
		explosion = false;
		currency = 150;
	}
	void CherryBombExplosion(CherryBomb& c, Clock sclock, bool grid_check[5][9]) {
		if (c.explosion == false && c.draw == true && c.shooting == true) {
			if (c.bulletClock.getElapsedTime().asSeconds() < 3)
				return;
			c.draw = false;
			c.explosion = true;
			c.shooting = false;
			c.x = 2000;
			c.y = 2000;
			grid_check[gridi][gridj] = false;

		}
		c.bulletClock.restart();
	}
	void CherryBombWithZombie(SimpleZombie& simplezombie, FootballZombie& footballZombie, FlyingZombie& flyingZombie, DancingZombie& dancingZombie) {
		if (draw == true) {
			if (x - 70 <= simplezombie.getPosition().x && x + 70 >= simplezombie.getPosition().x) {
				if (y - 80 <= simplezombie.getPosition().y && y + 80 >= simplezombie.getPosition().y) {
					simplezombie.setHealth(0);
				}
			}
			if (x - 70 <= footballZombie.getPosition().x && x + 70 >= footballZombie.getPosition().x) {
				if (y - 80 <= footballZombie.getPosition().y && y + 80 >= footballZombie.getPosition().y) {
					footballZombie.setHealth(0);
				}
			}
			if (x - 70 <= flyingZombie.getPosition().x && x + 70 >= flyingZombie.getPosition().x) {
				if (y - 80 <= flyingZombie.getPosition().y && y + 80 >= flyingZombie.getPosition().y) {
					flyingZombie.setHealth(0);
				}
			}
			if (x - 70 <= dancingZombie.getPosition().x && x + 70 >= dancingZombie.getPosition().x) {
				if (y - 80 <= dancingZombie.getPosition().y && y + 80 >= dancingZombie.getPosition().y) {
					dancingZombie.setHealth(0);
				}
			}
		}

	}
};