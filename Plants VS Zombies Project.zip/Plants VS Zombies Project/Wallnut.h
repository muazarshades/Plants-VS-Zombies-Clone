#pragma once

#include <ctime>
#include <iostream>
#include <SFML/Graphics.hpp>

#include "Shooter.h"
#include "Sunflower.h"

using namespace sf;
using namespace std;

class Wallnut : public Shooter {
public:
	int direction = 0;
public:
	Wallnut() {
		plantTexture.loadFromFile("Images/Wallnut.png");
		plantSprite.setTexture(plantTexture);
		plantSprite.setScale(0.15f, 0.15f);
		plantSprite.setTextureRect(sf::IntRect(0, 0, 348, 399));
		x = 0;
		y = 0;
		currency = 50;
	}

	void WallnutHit(Wallnut& wn, SimpleZombie& simplezombie, FootballZombie& footballZombie, FlyingZombie& flyingZombie, DancingZombie& dancingZombie) {

		if (wn.draw == true && simplezombie.getHealth() > 0) {
			if (simplezombie.getPosition().x <= wn.x + 20 && wn.x <= simplezombie.getPosition().x) {
				if (simplezombie.getPosition().y <= wn.y + 50 && wn.y <= simplezombie.getPosition().y) {

					if (wn.direction == 0) {
						wn.direction = 1;
					}
					else if (wn.direction == 1) {
						wn.direction = 2;
					}
					else if (wn.direction == 2) {
						wn.direction = 1;
					}
					simplezombie.setHealth(0);
				}
			}
		}
		if (wn.draw == true && footballZombie.getHealth() > 0) {
			if (footballZombie.getPosition().x <= wn.x + 20 && wn.x <= footballZombie.getPosition().x) {
				if (footballZombie.getPosition().y <= wn.y + 50 && wn.y <= footballZombie.getPosition().y) {

					if (wn.direction == 0) {
						wn.direction = 1;
					}
					else if (wn.direction == 1) {
						wn.direction = 2;
					}
					else if (wn.direction == 2) {
						wn.direction = 1;
					}
					footballZombie.setHealth(0);
				}
			}
		}
		if (wn.draw == true && flyingZombie.getHealth() > 0) {
			if (flyingZombie.getPosition().x <= wn.x + 20 && wn.x <= flyingZombie.getPosition().x) {
				if (flyingZombie.getPosition().y <= wn.y + 50 && wn.y <= flyingZombie.getPosition().y) {

					if (wn.direction == 0) {
						wn.direction = 1;
					}
					else if (wn.direction == 1) {
						wn.direction = 2;
					}
					else if (wn.direction == 2) {
						wn.direction = 1;
					}
					flyingZombie.setHealth(0);
				}
			}
		}
		if (wn.draw == true && dancingZombie.getHealth() > 0) {
			if (dancingZombie.getPosition().x <= wn.x + 20 && wn.x <= dancingZombie.getPosition().x) {
				if (dancingZombie.getPosition().y <= wn.y + 50 && wn.y <= dancingZombie.getPosition().y) {

					if (wn.direction == 0) {
						wn.direction = 1;
					}
					else if (wn.direction == 1) {
						wn.direction = 2;
					}
					else if (wn.direction == 2) {
						wn.direction = 1;
					}
					dancingZombie.setHealth(0);
				}
			}
		}
	}

	void MovingWallnut(Wallnut& wn) {
		if (wn.x > 800 || wn.y > 420) {
			wn.Health = 0;
		}
		if (wn.draw == true && wn.shooting == true) {
			if (wn.direction == 0) {
				wn.x = wn.x + 1;
				wn.y = wn.y;
			}
			else if (wn.direction == 1) {
				wn.x = wn.x + 1;
				wn.y = wn.y + 1;
			}
			else if (wn.direction == 2) {
				wn.x = wn.x + 1;
				wn.y = wn.y - 1;
			}
		}
	}
};