#pragma once

#include "Plant.h"
#include <ctime>
#include <iostream>
#include <SFML/Graphics.hpp>

using namespace sf;
using namespace std;

class Plant {

public:

	int x, y;
	int gridi=0, gridj=0;
	int Health=100;
	bool draw = false;
	int currency;
	sf::Texture plantTexture;
	sf::Sprite plantSprite;

public:
	void DrawPlant(sf::RenderWindow& window,bool grid_check[5][9]) {
		if (draw == true && Health > 0) {
			plantSprite.setPosition(x, y);
			window.draw(plantSprite);
		}

		else if (Health < 0) {
			x = 2000;
			y = 2000;
			grid_check[gridi][gridj] = false;
		}
	}
	
	void zombieEating(SimpleZombie& simplezombie, FootballZombie& footballZombie, FlyingZombie& flyingZombie, DancingZombie& dancingZombie) {
		if (draw == true && simplezombie.getHealth() > 0) {
			if (x + 30 >= simplezombie.getPosition().x && x<= simplezombie.getPosition().x ){
				if (y+60 >= simplezombie.getPosition().y &&  y<=simplezombie.getPosition().y ) {
					Health = Health - 1;
					simplezombie.setStop(true);
				}
			}
		}

		if (draw == true && footballZombie.getHealth() > 0) {
			if (x + 30 >= footballZombie.getPosition().x && x <= footballZombie.getPosition().x) {
				if (y + 60 >= footballZombie.getPosition().y && y <= simplezombie.getPosition().y) {
					Health = Health - 1;
					footballZombie.setStop(true);
				}
			}
		}

		if (draw == true && dancingZombie.getHealth() > 0) {
			if (x + 30 >= dancingZombie.getPosition().x && x <= dancingZombie.getPosition().x) {
				if (y + 60 >= dancingZombie.getPosition().y && y <= dancingZombie.getPosition().y) {
					Health = Health - 1;
					dancingZombie.setStop(true);
				}
			}
		}


	}
};