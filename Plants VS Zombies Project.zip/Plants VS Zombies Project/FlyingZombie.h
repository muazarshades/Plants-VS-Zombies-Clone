#pragma once
#include "Zombie.h"

class FlyingZombie : public Zombie {
public:
	FlyingZombie()
		: Zombie(15.0f, 3)
	{
		loadTexture(); // Load SimpleZombie texture
	}

	//for texture loading 
	void loadTexture() {
		texture.loadFromFile("Images/FlyingZombie.png");
		sprite.setTexture(texture);
		//sprite.setScale(0.25f, 0.25f);
		sprite.setTextureRect(sf::IntRect(0, 0, 293, 518));//new
		sprite.setScale(0.190f, 0.120);//new
	}

	void spawn() {
		sf::Time elapsedTime = zombieClock.getElapsedTime();

		if ((elapsedTime.asSeconds() > 100 || elapsedTime.asSeconds() > 200) && !alive) { // first time for initial spawn - second time for wave
			alive = true;
			zombieClock.restart();
		}
	}
};