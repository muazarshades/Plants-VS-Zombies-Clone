#pragma once

#include <ctime>
#include <iostream>
#include <SFML/Graphics.hpp>

#include "Shooter.h"

using namespace sf;
using namespace std;

class Repeater : public Shooter {
public:
public:
	Repeater() {
		plantTexture.loadFromFile("Images/Repeater.png");
		plantSprite.setTexture(plantTexture);
		plantSprite.setScale(0.15f, 0.15f);
		plantSprite.setTextureRect(sf::IntRect(0, 0, 469, 532));
		bulletTexture.loadFromFile("Images/Pea.png");
		bulletSprite.setTexture(bulletTexture);
		bulletSprite.setScale(0.71, 0.71);
		bulletSprite.setTextureRect(sf::IntRect(0, 0, 80, 80));
		x = 0;
		y = 0;
		currency = 200;

	}
	void MakingBullets() {
		if (shooting == true) {
			if (bulletClock.getElapsedTime().asSeconds() < 2)
				return;
			bulletClock.restart();
			int peascreated = 0;
			for (int j = 0; j < maxBullets; ++j) {
				if (peascreated < 2) {
					if (bullet[j][2] == 0) {
						bullet[j][0] = x + 50 + (peascreated * 20);
						bullet[j][1] = y + 10;
						bullet[j][2] = 1;
						++peascreated;
					}
				}
			}

		}
	}


};