#pragma once

#include <ctime>
#include <iostream>
#include <SFML/Graphics.hpp>


#include "Plant.h"
#include "Shooter.h"
#include "CherryBomb.h"
#include "Wallnut.h"
#include "FumeShroom.h"
#include "PeaShooter.h"
#include "Repeater.h"
#include "SnowPea.h"
#include "Sunflower.h"

using namespace sf;
using namespace std;

class PlantFactory {
public:
public:
	void makingPlants(Sunflower* s, PeaShooter* p, Repeater* r, SnowPea* snow, CherryBomb* bomb, Wallnut* wn, FumeShroom* fs, int n, int id, int x, int y, int gi, int gj, int& player_currency) {
		if (id == 1) {
			for (int i = 0;i < n;++i) {
				if (player_currency >= s[i].currency) {
					if (s[i].draw == false) {
						player_currency = player_currency - s[i].currency;
						s[i].gridi = gi;
						s[i].gridj = gj;
						s[i].x = x;
						s[i].y = y;
						s[i].draw = true;
						s[i].shooting = true;
						s[i].bulletClock.restart();
						break;
					}
				}
			}
		}
		if (id == 2) {

			for (int i = 0;i < n;++i) {
				if (player_currency >= p[i].currency) {
					if (p[i].draw == false) {
						player_currency = player_currency - p[i].currency;
						p[i].x = x;
						p[i].y = y;
						p[i].gridi = gi;
						p[i].gridj = gj;
						p[i].draw = true;
						p[i].shooting = true;
						break;
					}
				}
			}
		}
		if (id == 5) {
			for (int i = 0;i < n;++i) {
				if (player_currency >= r[i].currency) {
					if (r[i].draw == false) {
						player_currency = player_currency - r[i].currency;
						r[i].x = x;
						r[i].y = y;
						r[i].gridi = gi;
						r[i].gridj = gj;
						r[i].draw = true;
						r[i].shooting = true;
						r[i].bulletClock.restart();
						break;
					}
				}
			}
		}
		if (id == 6) {
			for (int i = 0;i < n;++i) {
				if (player_currency >= snow[i].currency) {
					if (snow[i].draw == false) {
						player_currency = player_currency - snow[i].currency;
						snow[i].x = x;
						snow[i].y = y;
						snow[i].gridi = gi;
						snow[i].gridj = gj;
						snow[i].draw = true;
						snow[i].shooting = true;
						snow[i].bulletClock.restart();
						break;
					}
				}
			}
		}


		if (id == 4) {
			for (int i = 0;i < n;++i) {
				if (player_currency >= bomb[i].currency) {
					if (bomb[i].draw == false && bomb[i].explosion == false) {
						player_currency = player_currency - bomb[i].currency;
						bomb[i].x = x;
						bomb[i].y = y;
						bomb[i].gridi = gi;
						bomb[i].gridj = gj;
						bomb[i].draw = true;
						bomb[i].shooting = true;
						bomb[i].bulletClock.restart();
						break;
					}
				}
			}
		}

		if (id == 3) {
			for (int i = 0;i < n;++i) {
				if (player_currency >= wn[i].currency) {
					if (wn[i].draw == false) {
						player_currency = player_currency - wn[i].currency;
						wn[i].x = x;
						wn[i].y = y;
						wn[i].gridi = gi;
						wn[i].gridj = gj;
						wn[i].draw = true;
						wn[i].shooting = true;
						break;
					}
				}
			}
		}

		if (id == 7) {
			for (int i = 0;i < n;++i) {
				if (player_currency >= fs[i].currency) {
					if (fs[i].draw == false) {
						player_currency = player_currency - fs[i].currency;
						fs[i].x = x;
						fs[i].y = y;
						fs[i].gridi = gi;
						fs[i].gridj = gj;
						fs[i].draw = true;
						fs[i].shooting = true;
						fs[i].bulletClock.restart();
						break;
					}
				}
			}
		}
	}
};