#pragma once



#include <ctime>
#include <iostream>
#include <SFML/Graphics.hpp>



#include "Plant.h"

using namespace sf;
using namespace std;




class Shooter : public Plant {

public:
	bool shooting = false;
	const int maxBullets = 100;
	int bullet[100][3];
	sf::Texture bulletTexture;
	sf::Sprite bulletSprite;
	sf::Clock bulletClock;
public:

	Shooter() {
		for (int i = 0;i < maxBullets;++i) {
			bullet[i][2] = 0;
		}
	}
	void DrawBullets(sf::RenderWindow& window) {
		for (int i = 0;i < maxBullets;++i) {
			if (bullet[i][2] == 1) {
				bulletSprite.setPosition(bullet[i][0], bullet[i][1]);
				window.draw(bulletSprite);
			}
		}
	}
	void MakingBullets() {
		if (shooting == true && draw == true) {
		if (bulletClock.getElapsedTime().asSeconds() < 3)
				return;
			bulletClock.restart();
			for (int j = 0; j < maxBullets; ++j) {
				if (bullet[j][2] == 0) {
					bullet[j][0] = x + 50;
					bullet[j][1] = y + 10;
					bullet[j][2] = 1;
					break;
				}
			}
		}
	}
	void MovingBullets(Clock sclock) {
		if (shooting == true) {

			if (sclock.getElapsedTime().asMilliseconds() < 10)
				return;
			sclock.restart();

			for (int i = 0; i < maxBullets; ++i) {
				if (bullet[i][2] == 1) {
					bullet[i][0] = bullet[i][0] + 4;

				}
			}
		}

	}

	
	void BulletCollision(SimpleZombie& simplezombie, FootballZombie& footballZombie, FlyingZombie& flyingZombie, DancingZombie& dancingZombie) {
		if (shooting == true && draw == true) {
			for (int i = 0; i < maxBullets; ++i) {
				if (bullet[i][2] == 1 && simplezombie.getHealth() > 0) {
					if (bullet[i][0] <= simplezombie.getPosition().x + 20 && simplezombie.getPosition().x <= bullet[i][0]) {
						if (bullet[i][1] <= simplezombie.getPosition().y + 50 && simplezombie.getPosition().y <= bullet[i][1]) {
							bullet[i][2] = 0;
							int health = simplezombie.getHealth();
							--health;
							simplezombie.setHealth(health);
						}
					}
				}
				if (bullet[i][2] == 1 && footballZombie.getHealth() > 0) {
					if (bullet[i][0] <= footballZombie.getPosition().x + 20 && footballZombie.getPosition().x <= bullet[i][0]) {
						if (bullet[i][1] <= footballZombie.getPosition().y + 50 && footballZombie.getPosition().y <= bullet[i][1]) {
							bullet[i][2] = 0;
							int health = footballZombie.getHealth();
							--health;
							footballZombie.setHealth(health);

						}
					}
				}
				if (bullet[i][2] == 1 && flyingZombie.getHealth() > 0) {
					if (bullet[i][0] <= flyingZombie.getPosition().x + 20 && flyingZombie.getPosition().x <= bullet[i][0]) {
						if (bullet[i][1] <= flyingZombie.getPosition().y + 50 && flyingZombie.getPosition().y <= bullet[i][1]) {
							bullet[i][2] = 0;
							int health = flyingZombie.getHealth();
							--health;
							flyingZombie.setHealth(health);
						}
					}
				}
				if (bullet[i][2] == 1 && dancingZombie.getHealth() > 0) {
					if (bullet[i][0] <= dancingZombie.getPosition().x + 20 && dancingZombie.getPosition().x <= bullet[i][0]) {
						if (bullet[i][1] <= dancingZombie.getPosition().y + 50 && dancingZombie.getPosition().y <= bullet[i][1]) {
							bullet[i][2] = 0;
							int health = dancingZombie.getHealth();
							--health;
							dancingZombie.setHealth(health);
						}
					}
				}
			}
		}
	}
	
};