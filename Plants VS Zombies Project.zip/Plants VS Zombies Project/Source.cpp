

#include <cstdlib> 
#include <ctime>  
#include <iostream>
#include <SFML/Graphics.hpp>
//___________________________________________Zombies______________________________________________________
#include "DancingZombie.h"
#include "FlyingZombie.h"
#include "FootballZombie.h"
#include "SimpleZombie.h"
#include "Zombie.h"
#include "ZombieFactory.h"
//____________________________________________Plants______________________________________________________
#include "CherryBomb.h"
#include "Menu.h"
#include "PeaShooter.h"
#include "Plant Factory.h"
#include "Repeater.h"
#include "Shooter.h"
#include "Sunflower.h"
#include "Wallnut.h"

using namespace sf;
using namespace std;

// Drawing Background
void createBack(RenderWindow& window, int level) {
	Image map_image;
	float scaleFactorx = 1.0f;
	float scaleFactory = 1.0f;
	if (level == 1) {
		map_image.loadFromFile("Images/Levels/Frontyard.png");
	}
	else if (level == 2) {
		map_image.loadFromFile("Images/Levels/Frontyard.png");
	}
	else if (level == 3) {
		map_image.loadFromFile("Images/Levels/limitedbg.jpg");
		scaleFactorx = 0.72f;
		scaleFactory = 0.72f;
	}
	else if (level == 4) {
		map_image.loadFromFile("Images/Levels/night.jpg");
		scaleFactorx = 0.72f;
		scaleFactory = 0.72f;
	}
	else if (level == 5) {
		map_image.loadFromFile("Images/Levels/night.jpg");
		scaleFactorx = 0.72f;
		scaleFactory = 0.72f;
	}
	else if (level == 6) {
		map_image.loadFromFile("Images/Levels/Roof.png");
		scaleFactorx = 0.80f;
		scaleFactory = 0.78f;
		Texture map;
		map.loadFromImage(map_image);
		Sprite s_map;
		s_map.setScale(scaleFactorx, scaleFactory);
		s_map.setTexture(map);
		s_map.setPosition(0, 0);
	}

	Texture map;
	map.loadFromImage(map_image);
	Sprite s_map;
	s_map.setScale(scaleFactorx, scaleFactory);
	s_map.setTexture(map);
	s_map.setPosition(0, 0);
	window.draw(s_map);
}
void creatFog(RenderWindow& window) {
	Image map_image;
	map_image.loadFromFile("Images/Levels/Fog.png");
	Texture map;
	map.loadFromImage(map_image);
	Sprite s_map;
	s_map.setScale(3.3, 1.1);
	s_map.setTexture(map);
	s_map.setPosition(400, -60);
	window.draw(s_map);
}

//Drawing Instructions
void createInstructions(RenderWindow& window) {
	sf::Font instruction;
	instruction.loadFromFile("Font/Chilanka-Regular.otf");
	sf::Text instructionText;
	instructionText.setFont(instruction);
	instructionText.setCharacterSize(20);
	instructionText.setStyle(sf::Text::Bold);
	instructionText.setFillColor(sf::Color::Red);
	instructionText.setPosition(130, 100);
	instructionText.setString("                           Welcome to Plants vs Zombies!\n    Your mission is to defend your home from waves of zombies.\n     Strategically place your plants to fend off the undead horde,\n                       collect sunlight to plant more defenses,\n           and unlock new plants and upgrades as you progress.\n    With each level presenting unique challenges and zombie types,\nadapt your strategy to survive and protect your house at all costs.\n                                            Press K to Start");
	

	Image map_image;
	map_image.loadFromFile("Images/Instructions.png");
	Texture map;
	map.loadFromImage(map_image);
	Sprite s_map;
	s_map.setScale(2.7, 0.53);
	s_map.setTexture(map);
	s_map.setPosition(124, 100);
	window.draw(s_map);
	window.draw(instructionText);
}

struct Pair {
	int x = 0;
	int y = 0;
};

int main()
{
	bool starting = false;
	int player_currency = 1000;

	//---------------------------------------- GRID ----------------------------------------
	Pair grid[5][9];
	bool grid_check[5][9];
	int px = 180;
	int py = 60;
	for (int i = 0; i < 5; ++i) {
		for (int j = 0; j < 9; ++j) {
			grid_check[i][j] = false;
		}
	}
	for (int i = 0; i < 5; ++i) {
		for (int j = 0; j < 9; ++j) {
			grid[i][j].x = px;
			grid[i][j].y = py;
			px = px + 60;
		}
		px = 180;
		py = py + 70;
	}

	// Create a window, n*n
	RenderWindow window(VideoMode(800, 420), "Plants Vs Zombies");
	Image icon;
	if (!icon.loadFromFile("Images/icon.png"))
	{
		return 1;
	}
	window.setIcon(32, 32, icon.getPixelsPtr());

	//---------------------------------------- CLOCKS ----------------------------------------
	Clock clock;
	Clock sclock;

	// ---------------------------------------- DISPLAYING SCORE ----------------------------------------
	sf::Font font;
	font.loadFromFile("Font/Chilanka-Regular.otf");
	sf::Text scoreText;
	scoreText.setFont(font);
	scoreText.setCharacterSize(20);
	scoreText.setStyle(sf::Text::Bold);
	scoreText.setFillColor(sf::Color::Black);
	scoreText.setPosition(700, 0);

	//---------------------------------------- DISPLAYING LEVEL ----------------------------------------
	sf::Font font2;
	font2.loadFromFile("Font/Chilanka-Regular.otf");
	sf::Text levelText;
	levelText.setFont(font2);
	levelText.setCharacterSize(20);
	levelText.setStyle(sf::Text::Bold);
	levelText.setFillColor(sf::Color::Black);
	levelText.setPosition(700, 20);

	//---------------------------------------- PLANT ----------------------------------------
	PlantFactory plantfactory;
	const int no_of_plants = 10;
	Sunflower s2[no_of_plants];
	PeaShooter p[no_of_plants];
	Wallnut wn[no_of_plants];
	CherryBomb bomb[no_of_plants];
	Repeater repeater[no_of_plants];
	SnowPea snow[no_of_plants];
	FumeShroom fs[no_of_plants];

	//---------------------------------------- ZOMBIE ----------------------------------------
	srand(time(0));
	//declare zombie factory here
	int no_of_zombies = 4;
	ZombieFactory zombieFactory;

	//---------------------------------------- LEVEL ----------------------------------------
	int level;
	cout << "Enter Level: ";
	cin >> level;
	while (level >= 7) {
		cout << "There are only 6 levels: ";
		cin >> level;
	}
	Menu m(level + 1);


	//------------------------------ PAUSING GAME AND PUTTING PLANTS-------------------------- 
	bool pause = false;
	bool mouseClicked = false;
	int spawn = 1;

	while (window.isOpen())
	{
		//cout << "player currency: " << player_currency << endl;
		sf::Event event;
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed || (sf::Keyboard::isKeyPressed(sf::Keyboard::R))) {
				window.close();
			}
		}

		float time = clock.getElapsedTime().asMicroseconds();
		clock.restart();
		time = time;

		//----------------------------- DISPLAYING THINGS ON WINDOW --------------------------
		createBack(window, level);
		scoreText.setString("Sun: " + to_string(player_currency));
		window.draw(scoreText);
		levelText.setString("Level: " + to_string(level));
		window.draw(levelText);

		//------------------------------ STARTS FROM HERE -------------------------------------
		if (starting == true) {

			//----------------------------- RELATED TO PLANTS ---------------------------------
			sf::Vector2i mousePosition = sf::Mouse::getPosition(window);
			int mouseX = mousePosition.x;
			int mouseY = mousePosition.y;

			if (sf::Keyboard::isKeyPressed(sf::Keyboard::P)) {
				pause = true;

			}
			while (pause) {
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) {
					pause = false;
				}
				sf::sleep(sf::milliseconds(10));
			}
			if (event.type == sf::Event::MouseButtonPressed) {
				if (event.mouseButton.button == sf::Mouse::Left) {
					for (int i = 0; i < 8; ++i) {
						if (mouseX <= m.slots[i].x + 25 && m.slots[i].x + 5 <= mouseX) {
							if (mouseY <= m.slots[i].y + 45 && m.slots[i].y <= mouseY) {
								spawn = m.slots[i].id;
								mouseClicked = true;
								break;
							}
						}
					}
					for (int i = 0;i < no_of_plants;++i) {
						s2[i].CollectSunFlower(s2[i], player_currency, mouseX, mouseY);
					}
				}
			}
			if (mouseClicked) {
				if (event.type == sf::Event::MouseButtonReleased) {
					if (event.mouseButton.button == sf::Mouse::Left) {
						for (int i = 0; i < 5; ++i) {
							for (int j = 0; j < 9; ++j) {
								if (mouseX <= grid[i][j].x + 55 && grid[i][j].x + 5 <= mouseX) {
									if (mouseY <= grid[i][j].y + 65 && grid[i][j].y <= mouseY) {

										if (grid_check[i][j] == true) {
											s2[0].draw == false;
										}
										if (grid_check[i][j] == false) {
											plantfactory.makingPlants(s2, p, repeater, snow, bomb, wn, fs, no_of_plants, spawn, grid[i][j].x, grid[i][j].y, i, j,player_currency);
											mouseClicked = false;
											
											if (spawn == 5 || spawn == 6) { grid_check[i][j] = false; }
											else {
												grid_check[i][j] = true;
											}
											spawn = 0;
										}
									}
								}
							}
						}

					}
				}

			}

			//----------------------------------- PLANT --------------------------------------
			for (int i = 0;i < no_of_plants;++i) {

				s2[i].MakingBullets(s2[i].bulletClock);
				p[i].MakingBullets();
				repeater[i].MakingBullets();
				snow[i].MakingBullets();
				fs[i].MakingBullets();

				//Plant Drawing
				s2[i].DrawPlant(window, grid_check);
				p[i].DrawPlant(window, grid_check);
				repeater[i].DrawPlant(window, grid_check);
				snow[i].DrawPlant(window, grid_check);
				bomb[i].DrawPlant(window, grid_check);
				wn[i].DrawPlant(window, grid_check);
				fs[i].DrawPlant(window, grid_check);

				//Plant Bullet Drawing
				p[i].DrawBullets(window);
				repeater[i].DrawBullets(window);
				snow[i].DrawBullets(window);
				fs[i].DrawBullets(window);
				s2[i].DrawBullets(window);

				//Plant Bullet Moving
				p[i].MovingBullets(sclock);
				repeater[i].MovingBullets(sclock);
				snow[i].MovingBullets(sclock);
				fs[i].MovingBullets(sclock);

				//Unique Plants
				wn[i].MovingWallnut(wn[i]);
				bomb[i].CherryBombExplosion(bomb[i], sclock, grid_check);

			}

			//---------------------------------------- ZOMBIE ----------------------------------------
			// Get elapsed time since last frame
			float deltaTime = clock.restart().asSeconds();
			zombieFactory.spawnZombies();
			zombieFactory.updateZombies(deltaTime);
			zombieFactory.drawZombies(window);

			
			//---------------------------------------- NEW FUNCTION ------------------------------------

			for (int i = 0; i < no_of_plants; i++) {
				for (int j = 0; j < no_of_zombies; j++) {

					wn[i].WallnutHit(wn[i], zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
					bomb[i].CherryBombWithZombie(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
					if (s2[i].draw == true) {
						s2[i].zombieEating(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
					}
					if (p[i].draw == true) {
						p[i].zombieEating(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
						p[i].BulletCollision(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
					}
					if (wn[i].draw == true) {
						wn[i].zombieEating(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
					}
					if (bomb[i].draw == true) {
						bomb[i].zombieEating(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
					}
					if (repeater[i].draw == true) {
						repeater[i].zombieEating(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
						repeater[i].BulletCollision(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
					}
					if (snow[i].draw == true) {
						snow[i].zombieEating(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
						snow[i].BulletCollision(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
					}
					if (fs[i].draw == true) {
						fs[i].zombieEating(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
						fs[i].BulletCollision(zombieFactory.simpleZombie[j], zombieFactory.footballZombie[j], zombieFactory.flyingZombie[j], zombieFactory.dancingZombie[j]);
					}
				}

			}
			if (sclock.getElapsedTime().asSeconds() > 5) {
				for (int j = 0; j < no_of_zombies; j++) {
					zombieFactory.simpleZombie[j].setStop(false);
					zombieFactory.footballZombie[j].setStop(false);
					zombieFactory.flyingZombie[j].setStop(false);
					zombieFactory.dancingZombie[j].setStop(false);
				}
				sclock.restart();
			}
			
			//---------------------------------------- MENU DRAW ----------------------------------------
			if (level == 4) {
				creatFog(window);
			}
			m.DrawingMenu(window);
			m.DrawingSlots(window);
			m.ChoosingSlots(m);
		}

		if (starting == false) {
			createInstructions( window);
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::K)) {
				starting = true;

			}
		}
		window.setSize(sf::Vector2u(800, 420));
		window.display();
	}
	return 0;
}
