#pragma once
#include <ctime>
#include <iostream>
#include <SFML/Graphics.hpp>


#include "Shooter.h"

using namespace sf;
using namespace std;

class SnowPea : public Shooter {
public:
public:
	SnowPea() {
		plantTexture.loadFromFile("Images/SnowPea.png");
		plantSprite.setTexture(plantTexture);
		plantSprite.setScale(0.82f, 0.82f);
		plantSprite.setTextureRect(sf::IntRect(0, 0, 71, 71));
		bulletTexture.loadFromFile("Images/icepea.png");
		bulletSprite.setTexture(bulletTexture);
		bulletSprite.setScale(0.50, 0.50);
		bulletSprite.setTextureRect(sf::IntRect(0, 0, 80, 80));
		x = 0;
		y = 0;
		currency = 150;
	}

};