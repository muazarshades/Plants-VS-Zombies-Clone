#pragma once
#include "Zombie.h"

class FootballZombie : public Zombie {
private:
	bool helmet;

public:
	FootballZombie()
		: Zombie(15.0f, 6), helmet(true)
	{
		loadTexture(); // Load SimpleZombie texture
	}

	//for texture loading 
	void loadTexture() {
		texture.loadFromFile("Images/FootballZombie.png");
		sprite.setTexture(texture);
		//sprite.setScale(0.14f, 0.14f);
		sprite.setScale(0.210f, 0.130);//new
	}

	void spawn() {
		sf::Time elapsedTime = zombieClock.getElapsedTime();

		if ((elapsedTime.asSeconds() > 60 || elapsedTime.asSeconds() > 200) && !alive) { // first time for initial spawn - second time for wave
			alive = true;
			zombieClock.restart();
		}
	}
};