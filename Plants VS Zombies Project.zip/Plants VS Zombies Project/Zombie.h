#pragma once
#include <SFML/Graphics.hpp>

class Zombie {
protected:
	sf::Sprite sprite;
	sf::Vector2f position;
	sf::Texture texture;
	float speed;
	int health;
	bool alive;
	bool stop;
	sf::Clock zombieClock;

public:
	Zombie(float zombieSpeed, int zombieHealth)
		: speed(zombieSpeed), health(zombieHealth), alive(false),stop(false) {

		position.x = 750.0f + (float)(rand() % 300); // initial x needs to be between 700 and 800
		position.y = ((rand() % 5) + 1) * 70.0f;// initial y needs to be between 0 and 350 and also be multiple of 70
		sprite.setPosition(position);
		//sprite.setScale(.1f, .1f);
		sprite.setScale(0.120f, 0.090);//new
		sprite.setTextureRect(sf::IntRect(0, 0, 469, 625));//new
		zombieClock.restart(); // Start the clock
	}

	void setPosition(sf::Vector2f p) {
		this->position.x = p.x;
		this->position.y = p.y;
	}

	sf::Vector2f getPosition() {
		return position;
	}
	void setHealth(int health) {
		this->health = health;
	}
	int getHealth() {
		return health;
	}
	void setStop(bool stop) {
		this->stop = stop;
	}
	int getStop() {
		return stop;
	}
	void moveZombie(float deltaTime) {

		if (alive && !stop) {
			position.x -= speed * deltaTime; // Move left
			sprite.setPosition(position);
			if (health == 0)
				alive = false;
		}
	}

	void draw(sf::RenderWindow& window) {
		if (alive) {
			window.draw(sprite);
			sf::Time elapsedTime = zombieClock.getElapsedTime();
		}
	}

	// Virtual function for loading texture, to be implemented by child class
	virtual void loadTexture() = 0;

	// Virtual because every zombie has different times to spawn/respawn
	virtual void spawn() = 0;



	//plant-zombie collision
	//virtual void plantZombieCollision() = 0;
};

/*
There will be multiple types of zombies that have different attributes, in particular, speed,
damage tolerance, and abilities which are described below.

1. SimpleZombie:
Just a normal zombie that will only move forward and will appear after a certain interval.
Their speed is slow and will destroyed if get three hits of pea.

2. FootballZombie:
Football zombies can move left and right and have double protection from helmets. Their
speed is normal.

3. FlyingZombie:
Flying zombies can fly through any plant on the field. It can't eat the plant either. Their
speed is normal.

4. DancingZombie:
Dancing Zombie able to summon other zombies from the ground and can move
diagonally. Their speed is high.
*/