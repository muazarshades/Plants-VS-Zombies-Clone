#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>


using namespace sf;
using namespace std;

struct slots {
public:
	int x, y = 0;
	int id;
	sf::Texture slotsTexture;
	sf::Sprite slotsSprite;
public:

};


class Menu {

public:
	const int x = 285, y = 0;
	sf::Texture menuTexture;
	sf::Sprite menuSprite;
	slots slots[8];
public:

	Menu(int n=2) {
		int j = x + 45;
		for (int i = 1;i <= n;++i) {
			slots[i].x = j;
			slots[i].id = i;
			j = j + 33;
		}
	}
	void DrawingMenu(sf::RenderWindow& window) {

		menuTexture.loadFromFile("Images/Deck.png");
		menuSprite.setTexture(menuTexture);
		menuSprite.setScale(0.60, 0.60);
		menuSprite.setTextureRect(sf::IntRect(0, 0, 522, 87));
		menuSprite.setPosition(285, 0);
		window.draw(menuSprite);

	}

	void ChoosingSlots(Menu m) {
		for (int i = 0;i < 8;++i) {
			if (m.slots[i].id == 1) {
				slots[i].slotsTexture.loadFromFile("Images/Slots/card_sunflower.png");
				slots[i].slotsSprite.setTexture(slots[i].slotsTexture);
				slots[i].slotsSprite.setScale(0.52, 0.52);
				slots[i].slotsSprite.setTextureRect(sf::IntRect(0, 0, 64, 89));
				slots[i].slotsSprite.setPosition(slots[i].x, slots[i].y);
			}
			else if (m.slots[i].id == 2) {
				slots[i].slotsTexture.loadFromFile("Images/Slots/card_peashooter.png");
				slots[i].slotsSprite.setTexture(slots[i].slotsTexture);
				slots[i].slotsSprite.setScale(0.52, 0.52);
				slots[i].slotsSprite.setTextureRect(sf::IntRect(0, 0, 64, 89));
				slots[i].slotsSprite.setPosition(slots[i].x, slots[i].y);
			}
			else if (m.slots[i].id == 3) {
				slots[i].slotsTexture.loadFromFile("Images/Slots/card_wallnut.png");
				slots[i].slotsSprite.setTexture(slots[i].slotsTexture);
				slots[i].slotsSprite.setScale(0.52, 0.52);
				slots[i].slotsSprite.setTextureRect(sf::IntRect(0, 0, 64, 89));
				slots[i].slotsSprite.setPosition(slots[i].x, slots[i].y);
			}
			else if (m.slots[i].id == 4) {
				slots[i].slotsTexture.loadFromFile("Images/Slots/card_cherrybomb.png");
				slots[i].slotsSprite.setTexture(slots[i].slotsTexture);
				slots[i].slotsSprite.setScale(0.52, 0.52);
				slots[i].slotsSprite.setTextureRect(sf::IntRect(0, 0, 64, 89));
				slots[i].slotsSprite.setPosition(slots[i].x, slots[i].y);
			}
			else if (m.slots[i].id == 5) {
				slots[i].slotsTexture.loadFromFile("Images/Slots/card_repeaterpea.png");
				slots[i].slotsSprite.setTexture(slots[i].slotsTexture);
				slots[i].slotsSprite.setScale(0.52, 0.52);
				slots[i].slotsSprite.setTextureRect(sf::IntRect(0, 0, 64, 89));
				slots[i].slotsSprite.setPosition(slots[i].x, slots[i].y);
			}
			else if (m.slots[i].id == 6) {
				slots[i].slotsTexture.loadFromFile("Images/Slots/card_snowpea.png");
				slots[i].slotsSprite.setTexture(slots[i].slotsTexture);
				slots[i].slotsSprite.setScale(0.52, 0.52);
				slots[i].slotsSprite.setTextureRect(sf::IntRect(0, 0, 64, 89));
				slots[i].slotsSprite.setPosition(slots[i].x, slots[i].y);
			}
			 else if (m.slots[i].id == 7) {
				slots[i].slotsTexture.loadFromFile("Images/Slots/card_fumeshroom.png");
				slots[i].slotsSprite.setTexture(slots[i].slotsTexture);
				slots[i].slotsSprite.setScale(0.63, 0.67);
				slots[i].slotsSprite.setTextureRect(sf::IntRect(0, 0, 48, 70));
				slots[i].slotsSprite.setPosition(slots[i].x, slots[i].y);
			}
		}

	}

	void DrawingSlots(sf::RenderWindow& window) {
		for (int i = 0;i < 8;++i) {
			window.draw(slots[i].slotsSprite);
		}
	}
};