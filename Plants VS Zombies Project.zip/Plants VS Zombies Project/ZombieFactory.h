#pragma once
#include "DancingZombie.h"
#include "FlyingZombie.h"
#include "FootballZombie.h"
#include "SimpleZombie.h"
#include "Zombie.h"

class ZombieFactory
{
public:

	SimpleZombie simpleZombie[4];
	FootballZombie footballZombie[4];
	FlyingZombie flyingZombie[4];
	DancingZombie dancingZombie[4];

	ZombieFactory() {}

	void spawnZombies() {
		for (int i = 0; i < 4; i++) {
			simpleZombie[i].spawn();
			footballZombie[i].spawn();
			flyingZombie[i].spawn();
			dancingZombie[i].spawn();
		}
	}

	void updateZombies(float deltaTime) {
		for (int i = 0; i < 4; i++) {
			simpleZombie[i].moveZombie(deltaTime);
			footballZombie[i].moveZombie(deltaTime);
			flyingZombie[i].moveZombie(deltaTime);
			dancingZombie[i].moveZombie(deltaTime);
		}
	}

	void drawZombies(sf::RenderWindow& window) {
		for (int i = 0; i < 4; i++) {
			simpleZombie[i].draw(window);
			footballZombie[i].draw(window);
			flyingZombie[i].draw(window);
			dancingZombie[i].draw(window);
		}
	}
};
